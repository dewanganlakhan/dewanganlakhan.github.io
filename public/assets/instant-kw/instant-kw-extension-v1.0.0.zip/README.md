# Instant KW - Google Autocomplete & Wildcard Harvester (Chrome Extension)

**Instant KW** is a Google Chrome Extension (Manifest V3) built to discover, harvest, and export Google Instant / Autocomplete suggestions across deep wildcard variations.

**Developed by:** [Lakhan Dewangan](https://lakhandewangan.com/)  
**Website:** [https://lakhandewangan.com/](https://lakhandewangan.com/)

---

## 🚀 Key Features

1. **Google Autocomplete Harvester**:
   - Captures instant search suggestions from Google in real-time.
   - High-speed direct API stream with customizable rate pacing.
   - Option for live visual Google Search tab automation.

2. **Full Wildcard & Modifier Expansions (Level 1)**:
   - **Exact Seed**: `[keyword]`
   - **Wildcard Asterisks**: `* [keyword]`, `[keyword] *`, `* [keyword] *`, `_ [keyword]`
   - **Alphabet Suffix**: `[keyword] a` through `[keyword] z`
   - **Alphabet Prefix**: `a [keyword]` through `z [keyword]`
   - **Numbers**: `[keyword] 0` through `[keyword] 9`
   - **Questions**: `how to [keyword]`, `what is [keyword]`, `why [keyword]`, `where [keyword]`, `can [keyword]`, etc.
   - **Intent Modifiers**: `[keyword] for`, `[keyword] vs`, `[keyword] with`, `best [keyword]`, `top [keyword]`, `free [keyword]`

3. **⚡ Deep Level 2 Inner Wildcard Harvester**:
   - For every suggestion discovered at Level 1, the extension automatically executes **inner `*` wildcard searches**:
     - `* [suggested_keyword]`
     - `[suggested_keyword] *`
     - `* [suggested_keyword] *`
   - Uncovers hidden long-tail keywords and ultra-specific sub-queries.

4. **Storage & 1-Per-Keyword CSV Export**:
   - Automatically stores all captured suggestions organized by root seed keyword in `chrome.storage.local`.
   - **Export 1 CSV per keyword** (e.g., `instant_kw_running_shoes_suggestions.csv`).
   - **Bulk Export All CSVs**: Automatically triggers individual CSV downloads for each harvested keyword.
   - **One-Click Clipboard Copy**: Export clean list ready for Google Sheets / Excel.

5. **Keyword Studio Dashboard**:
   - Interactive full-page dashboard (`dashboard.html`) to manage projects, filter by wildcard categories (including `Deep L2 (*)`), search keywords, and inspect ranking position data.

---

## 🛠️ Installation Instructions

1. Open Google Chrome and navigate to `chrome://extensions/`.
2. Enable **Developer mode** via the toggle in the top-right corner.
3. Click the **Load unpacked** button.
4. Select the directory:
   ```
   /Users/lakhandewangan/ToolSites/Instant Kw
   ```
5. The extension **Instant KW** is now active and ready to use in your toolbar!

---

## 📊 CSV Export Format

Each exported CSV contains structured keyword intelligence:

| Seed Keyword | Suggested Keyword | Wildcard / Query Pattern | Pattern Type | Search Depth | Parent Suggestion | Rank Position | Timestamp |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `running shoes` | `best running shoes for flat feet` | `best running shoes` | Modifier Prefix (best) | Level 1 | | 1 | 2026-08-27T07:28:00.000Z |
| `running shoes` | `best running shoes for flat feet womens 2026` | `* best running shoes for flat feet *` | Deep L2 Both (*) | Level 2 | best running shoes for flat feet | 2 | 2026-08-27T07:28:10.000Z |

---

## 📂 File Structure

```
Instant Kw/
├── manifest.json         # Chrome Extension Manifest V3 configuration
├── background.js         # Service Worker (Harvesting queue, API suggest, CSV downloads)
├── content_script.js     # Google page DOM interaction script
├── popup.html            # Extension popup interface
├── popup.css             # Glassmorphism dark-theme popup styles
├── popup.js              # Popup controller logic & real-time feed
├── dashboard.html        # Full Keyword Studio Workspace page
├── dashboard.css         # Studio dashboard styles
├── dashboard.js          # Studio dashboard controller & tables
├── icons/                # Extension icon assets (16px, 48px, 128px, SVG)
└── README.md             # Documentation & Setup guide
```
