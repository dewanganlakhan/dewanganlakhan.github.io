# Privacy Policy for Instant KW - Google Autocomplete & Wildcard Harvester

**Last updated: August 27, 2026**

## 1. Overview
"Instant KW - Google Autocomplete & Wildcard Harvester" ("Extension") is committed to protecting your privacy. This Privacy Policy explains our practices regarding user data.

## 2. Information We Collect and How It Is Used
- **No Personal Data Collection:** The Extension does NOT collect, transmit, track, or sell any personally identifiable information (PII), browsing history, IP addresses, or search credentials.
- **Local Storage Only:** Any seed keywords entered and the suggestions returned from Google Autocomplete are stored exclusively on your local computer using the browser's `chrome.storage.local` API.
- **No Third-Party Transmission:** None of your stored keywords or exported CSV data are ever transmitted to any external servers, third-party analytics platforms, or developers.

## 3. Permissions Explanation
The Extension requests the minimum permissions required for its single purpose:
- **`storage`**: To store your keyword projects locally on your computer so you can access them in the history and dashboard.
- **`downloads`**: To allow you to download CSV files of your keywords directly to your local downloads folder.
- **`tabs` / `activeTab` / `scripting`**: To open the Keyword Studio dashboard tab in your browser and provide optional fallback suggestion harvesting.
- **Host Permissions (`*://suggestqueries.google.com/*`, `*://*.google.com/*`)**: To fetch real-time search suggestion queries from Google's public autocomplete endpoint on your behalf.

## 4. Single Purpose Declaration
The sole purpose of this Extension is to assist users in keyword research by harvesting Google Autocomplete suggestions and wildcard variations and exporting them to CSV format.

## 5. Developer & Contact
- **Developer:** Lakhan Dewangan
- **Website:** [https://lakhandewangan.com/](https://lakhandewangan.com/)
- **Support / Questions:** Please contact via [https://lakhandewangan.com/](https://lakhandewangan.com/) or the Chrome Web Store support dashboard.
