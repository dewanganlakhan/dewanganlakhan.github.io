/**
 * Instant KW - Content Script
 * Injected on Google search pages for DOM inspection and autocomplete capture
 */

(() => {
  // Listen for messages from background/popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_DOM_SUGGESTIONS') {
      const suggestions = extractSuggestionsFromPage();
      sendResponse({ success: true, suggestions });
      return true;
    }

    if (message.type === 'SIMULATE_INPUT') {
      const { query } = message;
      simulateSearchInput(query).then(suggestions => {
        sendResponse({ success: true, suggestions });
      });
      return true;
    }
  });

  function extractSuggestionsFromPage() {
    const list = [];
    const selectors = [
      'ul[role="listbox"] li span',
      'div[role="presentation"] ul li',
      '.wM6W7d span',
      '.sbct .sbtc',
      '.erkvQe li'
    ];

    selectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        const text = el.innerText?.trim();
        if (text && text.length > 1 && !list.includes(text) && !text.includes('Remove') && !text.includes('Delete')) {
          list.push(text);
        }
      });
    });

    return list;
  }

  async function simulateSearchInput(query) {
    const searchInput = document.querySelector('textarea[name="q"], input[name="q"]');
    if (!searchInput) return [];

    searchInput.focus();
    searchInput.value = query;
    searchInput.dispatchEvent(new Event('input', { bubbles: true }));
    searchInput.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: ' ' }));

    // Wait for dropdown to populate
    await new Promise(r => setTimeout(r, 600));
    return extractSuggestionsFromPage();
  }
})();
