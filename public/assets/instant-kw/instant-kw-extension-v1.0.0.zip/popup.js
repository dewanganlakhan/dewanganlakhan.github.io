/**
 * Instant KW - Popup Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const keywordsInput = document.getElementById('keywordsInput');
  const kwCountBadge = document.getElementById('kwCountBadge');
  const btnOpenDashboard = document.getElementById('btnOpenDashboard');
  const btnToggleAllOptions = document.getElementById('btnToggleAllOptions');
  
  // Option pills
  const optAsterisk = document.getElementById('optAsterisk');
  const optAlphabetSuffix = document.getElementById('optAlphabetSuffix');
  const optAlphabetPrefix = document.getElementById('optAlphabetPrefix');
  const optNumbers = document.getElementById('optNumbers');
  const optQuestions = document.getElementById('optQuestions');
  const optPrepositions = document.getElementById('optPrepositions');
  const optDeepLevel2 = document.getElementById('optDeepLevel2');
  const allOptionCheckboxes = [optAsterisk, optAlphabetSuffix, optAlphabetPrefix, optNumbers, optQuestions, optPrepositions, optDeepLevel2];

  // Settings
  const selectCountry = document.getElementById('selectCountry');
  const selectLanguage = document.getElementById('selectLanguage');
  const speedSlider = document.getElementById('speedSlider');
  const delayValueLabel = document.getElementById('delayValueLabel');

  // Actions
  const btnStartScrape = document.getElementById('btnStartScrape');
  const btnStopScrape = document.getElementById('btnStopScrape');

  // Progress & Feed
  const progressSection = document.getElementById('progressSection');
  const progressBarFill = document.getElementById('progressBarFill');
  const progressPercentage = document.getElementById('progressPercentage');
  const statQueriesDone = document.getElementById('statQueriesDone');
  const statSuggestionsFound = document.getElementById('statSuggestionsFound');
  const currentQueryText = document.getElementById('currentQueryText');
  const liveFeedSection = document.getElementById('liveFeedSection');
  const liveFeedList = document.getElementById('liveFeedList');
  const liveFeedCount = document.getElementById('liveFeedCount');

  // Exports & Utilities
  const popupHistoryList = document.getElementById('popupHistoryList');
  const historyCountBadge = document.getElementById('historyCountBadge');
  const btnExportAllCsvs = document.getElementById('btnExportAllCsvs');
  const btnCopyClipboard = document.getElementById('btnCopyClipboard');
  const btnClearStorage = document.getElementById('btnClearStorage');
  const toast = document.getElementById('toast');

  let lastActiveSeed = '';

  // 1. Initialize & sync option pills
  allOptionCheckboxes.forEach(cb => {
    if (!cb) return;
    cb.addEventListener('change', () => {
      const pill = cb.closest('.option-pill');
      if (cb.checked) {
        pill.classList.add('active');
      } else {
        pill.classList.remove('active');
      }
      saveSettings();
    });
  });

  // Select all / Deselect all
  btnToggleAllOptions.addEventListener('click', () => {
    const anyUnchecked = allOptionCheckboxes.some(cb => cb && !cb.checked);
    allOptionCheckboxes.forEach(cb => {
      if (!cb) return;
      cb.checked = anyUnchecked;
      const pill = cb.closest('.option-pill');
      if (anyUnchecked) pill.classList.add('active');
      else pill.classList.remove('active');
    });
    btnToggleAllOptions.textContent = anyUnchecked ? 'Deselect All' : 'Select All';
    saveSettings();
  });

  // 2. Keyword input parsing & count
  function getKeywordsList() {
    const raw = keywordsInput.value || '';
    return raw
      .split(/[\n,]+/)
      .map(k => k.trim())
      .filter(k => k.length > 0);
  }

  keywordsInput.addEventListener('input', () => {
    const list = getKeywordsList();
    kwCountBadge.textContent = `${list.length} keyword${list.length === 1 ? '' : 's'}`;
    chrome.storage.local.set({ instant_kw_last_input: keywordsInput.value });
  });

  // 3. Speed slider
  speedSlider.addEventListener('input', () => {
    const val = speedSlider.value;
    delayValueLabel.textContent = `${val}ms (${val < 300 ? 'Ultra Fast' : val <= 600 ? 'Safe Fast' : 'Relaxed'})`;
    saveSettings();
  });

  // Save / Load settings
  async function saveSettings() {
    const settings = {
      useAsteriskWildcard: optAsterisk.checked,
      useAlphabetSuffix: optAlphabetSuffix.checked,
      useAlphabetPrefix: optAlphabetPrefix.checked,
      useNumbers: optNumbers.checked,
      useQuestions: optQuestions.checked,
      usePrepositions: optPrepositions.checked,
      useDeepLevel2Wildcard: optDeepLevel2.checked,
      country: selectCountry.value,
      language: selectLanguage.value,
      delayMs: parseInt(speedSlider.value, 10)
    };
    await chrome.storage.local.set({ instant_kw_settings: settings });
  }

  async function loadSettings() {
    const stored = await chrome.storage.local.get(['instant_kw_settings', 'instant_kw_last_input']);
    if (stored.instant_kw_settings) {
      const s = stored.instant_kw_settings;
      optAsterisk.checked = s.useAsteriskWildcard ?? true;
      optAlphabetSuffix.checked = s.useAlphabetSuffix ?? true;
      optAlphabetPrefix.checked = s.useAlphabetPrefix ?? true;
      optNumbers.checked = s.useNumbers ?? true;
      optQuestions.checked = s.useQuestions ?? true;
      optPrepositions.checked = s.usePrepositions ?? true;
      if (optDeepLevel2) optDeepLevel2.checked = s.useDeepLevel2Wildcard ?? true;
      if (s.country) selectCountry.value = s.country;
      if (s.language) selectLanguage.value = s.language;
      if (s.delayMs) {
        speedSlider.value = s.delayMs;
        delayValueLabel.textContent = `${s.delayMs}ms (${s.delayMs < 300 ? 'Ultra Fast' : s.delayMs <= 600 ? 'Safe Fast' : 'Relaxed'})`;
      }

      allOptionCheckboxes.forEach(cb => {
        if (!cb) return;
        const pill = cb.closest('.option-pill');
        if (cb.checked) pill.classList.add('active');
        else pill.classList.remove('active');
      });
    }

    if (stored.instant_kw_last_input) {
      keywordsInput.value = stored.instant_kw_last_input;
      const list = getKeywordsList();
      kwCountBadge.textContent = `${list.length} keyword${list.length === 1 ? '' : 's'}`;
    }
  }

  // 4. Render Keyword History List
  async function loadHistory() {
    const stored = await chrome.storage.local.get('instant_kw_data');
    const data = stored.instant_kw_data || {};
    const seeds = Object.keys(data);

    historyCountBadge.textContent = `${seeds.length} saved`;

    if (seeds.length === 0) {
      popupHistoryList.innerHTML = `<div class="empty-history">No keyword history yet. Enter keywords above and start harvesting!</div>`;
      return;
    }

    // Sort by recent timestamp
    seeds.sort((a, b) => {
      const timeA = new Date(data[a].updatedAt || 0).getTime();
      const timeB = new Date(data[b].updatedAt || 0).getTime();
      return timeB - timeA;
    });

    popupHistoryList.innerHTML = '';
    seeds.forEach(seed => {
      const project = data[seed];
      const count = project.totalSuggestions || (project.suggestions ? Object.keys(project.suggestions).length : 0);
      const timeStr = project.updatedAt ? new Date(project.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
      const countryCode = (project.country || 'us').toUpperCase();
      const langCode = (project.language || 'en').toUpperCase();

      const item = document.createElement('div');
      item.className = 'history-item';
      item.innerHTML = `
        <div class="history-left" title="Click to fill into input box">
          <div class="history-title-row">
            <span class="history-name">${escapeHtml(seed)}</span>
            <span class="history-geo-badge">${countryCode} / ${langCode}</span>
          </div>
          <span class="history-meta">
            <span>${count} suggestions</span>
            ${timeStr ? `<span>• ${timeStr}</span>` : ''}
          </span>
        </div>
        <div class="history-actions">
          <button class="history-action-btn download" title="Download CSV for ${escapeHtml(seed)} (${countryCode}_${langCode})">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="7 10 12 15 17 10"></polyline>
              <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
          </button>
          <button class="history-action-btn delete" title="Delete keyword ${escapeHtml(seed)}">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
          </button>
        </div>
      `;

      // Fill into input on click and sync region
      item.querySelector('.history-left').addEventListener('click', () => {
        keywordsInput.value = seed;
        if (project.country) selectCountry.value = project.country.toLowerCase();
        if (project.language) selectLanguage.value = project.language.toLowerCase();
        const list = getKeywordsList();
        kwCountBadge.textContent = `${list.length} keyword${list.length === 1 ? '' : 's'}`;
        lastActiveSeed = seed;
        showToast(`Loaded "${seed}" (${countryCode}/${langCode}) into input`);
      });

      // Download CSV
      item.querySelector('.download').addEventListener('click', (e) => {
        e.stopPropagation();
        exportSingleKeyword(seed);
      });

      // Delete keyword
      item.querySelector('.delete').addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm(`Delete keyword "${seed}" and its saved suggestions?`)) {
          chrome.runtime.sendMessage({ type: 'DELETE_KEYWORD', seed }, () => {
            loadHistory();
            showToast(`Deleted "${seed}"`);
          });
        }
      });

      popupHistoryList.appendChild(item);
    });
  }

  function exportSingleKeyword(seed) {
    if (!seed) return;
    chrome.runtime.sendMessage({ type: 'EXPORT_KEYWORD_CSV', seed }, (res) => {
      if (res && res.success) {
        if (res.csvContent) {
          triggerBrowserDownload(res.csvContent, res.filename);
        }
        showToast(`Exported CSV for "${seed}"!`);
      } else {
        showToast(res?.error || 'No suggestions to export.');
      }
    });
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  await loadSettings();
  await loadHistory();

  // 4. Check active background task
  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (status) => {
    if (status && status.isRunning) {
      setUIRunningState(true);
      updateStatusUI(status);
    }
  });

  function setUIRunningState(isRunning) {
    if (isRunning) {
      btnStartScrape.classList.add('hidden');
      btnStopScrape.classList.remove('hidden');
      progressSection.classList.remove('hidden');
      liveFeedSection.classList.remove('hidden');
      keywordsInput.disabled = true;
    } else {
      btnStartScrape.classList.remove('hidden');
      btnStopScrape.classList.add('hidden');
      keywordsInput.disabled = false;
    }
  }

  function updateStatusUI(status) {
    if (!status) return;
    const { totalQueries, completedQueries, totalSuggestionsFound, currentKeyword, currentVariation, progressPercent } = status;

    if (currentKeyword) lastActiveSeed = currentKeyword;
    progressBarFill.style.width = `${progressPercent}%`;
    progressPercentage.textContent = `${progressPercent}%`;
    statQueriesDone.textContent = `${completedQueries} / ${totalQueries}`;
    statSuggestionsFound.textContent = totalSuggestionsFound.toLocaleString();
    
    if (currentVariation) {
      currentQueryText.textContent = `"${currentVariation}" (${currentKeyword})`;
    }
  }

  function appendLiveItem(kw, type) {
    const item = document.createElement('div');
    item.className = 'feed-item';
    item.innerHTML = `
      <span class="feed-kw" title="${kw}">${kw}</span>
      <span class="feed-type">${type || 'Suggestion'}</span>
    `;
    liveFeedList.prepend(item);

    // Keep max 20 items in live popup feed
    while (liveFeedList.children.length > 20) {
      liveFeedList.removeChild(liveFeedList.lastChild);
    }
  }

  // 5. Start / Stop Actions
  btnStartScrape.addEventListener('click', async () => {
    const list = getKeywordsList();
    if (list.length === 0) {
      showToast('Please enter at least one seed keyword.');
      keywordsInput.focus();
      return;
    }

    lastActiveSeed = list[0];
    liveFeedList.innerHTML = '';
    liveFeedCount.textContent = '0 found';

    const options = {
      useAsteriskWildcard: optAsterisk.checked,
      useAlphabetSuffix: optAlphabetSuffix.checked,
      useAlphabetPrefix: optAlphabetPrefix.checked,
      useNumbers: optNumbers.checked,
      useQuestions: optQuestions.checked,
      usePrepositions: optPrepositions.checked,
      useDeepLevel2Wildcard: optDeepLevel2 ? optDeepLevel2.checked : true,
      country: selectCountry.value,
      language: selectLanguage.value,
      delayMs: parseInt(speedSlider.value, 10)
    };

    setUIRunningState(true);

    chrome.runtime.sendMessage({
      type: 'START_EXTRACTION',
      keywords: list,
      options: options
    }, (res) => {
      if (res && res.success) {
        showToast(`Harvesting started (${res.totalQueries} queries queued)...`);
      } else {
        setUIRunningState(false);
        showToast(res?.error || 'Failed to start harvesting.');
      }
    });
  });

  btnStopScrape.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'STOP_EXTRACTION' }, () => {
      setUIRunningState(false);
      showToast('Harvesting stopped.');
    });
  });

  // 6. Realtime Message Listener
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'KW_STATUS_UPDATE') {
      updateStatusUI(msg.status);
      if (!msg.status.isRunning) {
        setUIRunningState(false);
      }
    } else if (msg.type === 'KW_NEW_SUGGESTIONS') {
      if (msg.suggestions && msg.suggestions.length > 0) {
        msg.suggestions.forEach(s => appendLiveItem(s.suggestion, s.patternType));
      }
      liveFeedCount.textContent = `${msg.totalFound} found`;
    } else if (msg.type === 'KW_EXTRACTION_FINISHED') {
      setUIRunningState(false);
      loadHistory();
      showToast(`Finished! Found ${msg.totalFound} keywords total.`);
    }
  });

  // 7. Export All CSVs (1 CSV file per keyword)
  btnExportAllCsvs.addEventListener('click', async () => {
    showToast('Exporting CSV for each keyword...');
    chrome.runtime.sendMessage({ type: 'EXPORT_ALL_CSVS' }, (res) => {
      if (res && res.success) {
        showToast(`Successfully generated ${res.exportedCount} CSV file(s)!`);
      } else {
        showToast(res?.error || 'No saved keywords to export.');
      }
    });
  });

  // 9. Copy to Clipboard
  btnCopyClipboard.addEventListener('click', async () => {
    chrome.storage.local.get('instant_kw_data', (stored) => {
      const data = stored.instant_kw_data || {};
      const list = getKeywordsList();
      const targetSeed = lastActiveSeed || (list.length > 0 ? list[0] : Object.keys(data)[0]);

      if (!targetSeed || !data[targetSeed] || !data[targetSeed].suggestions) {
        showToast('No keywords available to copy.');
        return;
      }

      const suggestions = Object.values(data[targetSeed].suggestions).map(s => s.keyword);
      if (suggestions.length === 0) {
        showToast('No keywords captured yet.');
        return;
      }

      navigator.clipboard.writeText(suggestions.join('\n')).then(() => {
        showToast(`Copied ${suggestions.length} keywords to clipboard!`);
      }).catch(() => {
        showToast('Clipboard access denied.');
      });
    });
  });

  // 10. Clear Storage
  btnClearStorage.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear all stored keywords and history?')) {
      chrome.runtime.sendMessage({ type: 'CLEAR_ALL_DATA' }, () => {
        liveFeedList.innerHTML = '';
        liveFeedCount.textContent = '0 found';
        statQueriesDone.textContent = '0 / 0';
        statSuggestionsFound.textContent = '0';
        progressBarFill.style.width = '0%';
        progressPercentage.textContent = '0%';
        loadHistory();
        showToast('All stored data cleared.');
      });
    }
  });

  // 11. Open Dashboard Tab
  btnOpenDashboard.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
  });

  // Helper download trigger
  function triggerBrowserDownload(csvContent, filename) {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Toast notifier
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.remove('hidden');
    toast.style.opacity = '1';
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.classList.add('hidden'), 300);
    }, 2800);
  }
});
