/**
 * Instant KW - Google Autocomplete & Wildcard Harvester
 * Background Service Worker (Manifest V3)
 */

// Storage keys
const STORAGE_KEY_DATA = 'instant_kw_data';
const STORAGE_KEY_SETTINGS = 'instant_kw_settings';

// Active scraping state
let activeTask = {
  isRunning: false,
  isPaused: false,
  totalQueries: 0,
  completedQueries: 0,
  totalSuggestionsFound: 0,
  currentKeyword: '',
  currentVariation: '',
  queue: [],
  resultsByKeyword: {},
  startedAt: null,
  stopRequested: false
};

// Default extraction settings
const defaultSettings = {
  delayMs: 350,
  country: 'us',
  language: 'en',
  useAsteriskWildcard: true,
  useAlphabetSuffix: true,
  useAlphabetPrefix: true,
  useNumbers: true,
  useQuestions: true,
  usePrepositions: true,
  useDeepLevel2Wildcard: true,
  openTabMode: false
};

/**
 * Generate query variations with wildcard combinations
 */
function generateVariations(seed, options) {
  const cleanSeed = seed.trim();
  if (!cleanSeed) return [];

  const variations = [];
  const added = new Set();

  function add(q, type) {
    const formatted = q.trim();
    if (formatted && !added.has(formatted.toLowerCase())) {
      added.add(formatted.toLowerCase());
      variations.push({ query: formatted, type, depth: 1 });
    }
  }

  // 1. Exact Seed Keyword
  add(cleanSeed, 'Exact Seed');

  // 2. Asterisk Wildcards
  if (options.useAsteriskWildcard) {
    add(`* ${cleanSeed}`, 'Wildcard Prefix (*)');
    add(`${cleanSeed} *`, 'Wildcard Suffix (*)');
    add(`* ${cleanSeed} *`, 'Wildcard Both (*)');
    add(`_ ${cleanSeed}`, 'Underscore Prefix (_)');
    add(`${cleanSeed} _`, 'Underscore Suffix (_)');
  }

  // 3. Alphabet Suffix (a-z)
  if (options.useAlphabetSuffix) {
    const letters = 'abcdefghijklmnopqrstuvwxyz'.split('');
    letters.forEach(letter => {
      add(`${cleanSeed} ${letter}`, `Alphabet Suffix (${letter})`);
    });
  }

  // 4. Alphabet Prefix (a-z)
  if (options.useAlphabetPrefix) {
    const letters = 'abcdefghijklmnopqrstuvwxyz'.split('');
    letters.forEach(letter => {
      add(`${letter} ${cleanSeed}`, `Alphabet Prefix (${letter})`);
    });
  }

  // 5. Numbers (0-9)
  if (options.useNumbers) {
    for (let i = 0; i <= 9; i++) {
      add(`${cleanSeed} ${i}`, `Number Suffix (${i})`);
      add(`${i} ${cleanSeed}`, `Number Prefix (${i})`);
    }
  }

  // 6. Question Starters
  if (options.useQuestions) {
    const questions = ['how to', 'how', 'what is', 'what', 'why', 'where', 'who', 'when', 'can', 'which', 'is', 'are'];
    questions.forEach(q => {
      add(`${q} ${cleanSeed}`, `Question Starter (${q})`);
    });
  }

  // 7. Search Intent & Prepositions
  if (options.usePrepositions) {
    const preps = ['for', 'with', 'without', 'vs', 'to', 'in', 'near', 'best', 'top', 'cheap', 'online', 'free'];
    preps.forEach(p => {
      add(`${cleanSeed} ${p}`, `Modifier Suffix (${p})`);
      if (['best', 'top', 'cheap', 'free'].includes(p)) {
        add(`${p} ${cleanSeed}`, `Modifier Prefix (${p})`);
      }
    });
  }

  return variations;
}

/**
 * Generate Level 2 inner wildcard queries for a given suggestion
 */
function generateLevel2Wildcards(suggestion) {
  const clean = suggestion.trim();
  if (!clean || clean.length < 3) return [];
  
  return [
    { query: `* ${clean}`, type: 'Deep L2 Prefix (*)', depth: 2 },
    { query: `${clean} *`, type: 'Deep L2 Suffix (*)', depth: 2 },
    { query: `* ${clean} *`, type: 'Deep L2 Both (*)', depth: 2 }
  ];
}

/**
 * Fetch autocomplete suggestions from Google Suggest API
 */
async function fetchGoogleSuggestions(query, hl = 'en', gl = 'us') {
  const url = `https://suggestqueries.google.com/complete/search?client=chrome&q=${encodeURIComponent(query)}&hl=${hl}&gl=${gl}`;
  
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json, text/plain, */*'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP status ${response.status}`);
    }

    const data = await response.json();
    if (Array.isArray(data) && Array.isArray(data[1])) {
      return data[1].map(item => typeof item === 'string' ? item : item[0]);
    }
    return [];
  } catch (err) {
    console.warn(`[Instant KW] Direct API fetch failed for "${query}":`, err.message);
    return [];
  }
}

/**
 * Save collected keyword results into chrome.storage.local
 */
async function persistResults(seedKeyword, newItems, options = {}) {
  const stored = await chrome.storage.local.get(STORAGE_KEY_DATA);
  const data = stored[STORAGE_KEY_DATA] || {};

  if (!data[seedKeyword]) {
    data[seedKeyword] = {
      seed: seedKeyword,
      country: (options.country || 'us').toLowerCase(),
      language: (options.language || 'en').toLowerCase(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      totalSuggestions: 0,
      suggestions: {}
    };
  }

  const project = data[seedKeyword];
  project.updatedAt = new Date().toISOString();
  if (options.country) project.country = options.country.toLowerCase();
  if (options.language) project.language = options.language.toLowerCase();

  let addedCount = 0;
  for (const item of newItems) {
    const key = item.suggestion.toLowerCase().trim();
    if (!project.suggestions[key]) {
      project.suggestions[key] = {
        keyword: item.suggestion,
        seed: seedKeyword,
        queryUsed: item.queryUsed,
        patternType: item.patternType,
        depth: item.depth || 1,
        parentSuggestion: item.parentSuggestion || '',
        country: project.country,
        language: project.language,
        rank: item.rank,
        timestamp: new Date().toISOString()
      };
      addedCount++;
    }
  }

  project.totalSuggestions = Object.keys(project.suggestions).length;
  await chrome.storage.local.set({ [STORAGE_KEY_DATA]: data });
  return addedCount;
}

/**
 * Execute Queue Loop
 */
async function processQueue() {
  if (!activeTask.isRunning || activeTask.stopRequested) {
    activeTask.isRunning = false;
    broadcastStatus();
    return;
  }

  const enqueuedLevel2Set = new Set();

  while (activeTask.queue.length > 0 && !activeTask.stopRequested) {
    const job = activeTask.queue.shift();
    activeTask.currentKeyword = job.seed;
    activeTask.currentVariation = job.query;

    let suggestions = [];

    // Optional Tab Automation Mode or Direct API
    if (job.options.openTabMode) {
      suggestions = await runTabAutomation(job.query);
      if (suggestions.length === 0) {
        suggestions = await fetchGoogleSuggestions(job.query, job.options.language, job.options.country);
      }
    } else {
      suggestions = await fetchGoogleSuggestions(job.query, job.options.language, job.options.country);
    }

    if (suggestions.length > 0) {
      const items = suggestions.map((sugg, idx) => ({
        suggestion: sugg,
        queryUsed: job.query,
        patternType: job.type,
        depth: job.depth || 1,
        parentSuggestion: job.parentSuggestion || '',
        country: job.options.country || 'us',
        language: job.options.language || 'en',
        rank: idx + 1
      }));

      const added = await persistResults(job.seed, items, job.options);
      activeTask.totalSuggestionsFound += added;

      // Realtime notification of newly found suggestions
      chrome.runtime.sendMessage({
        type: 'KW_NEW_SUGGESTIONS',
        seed: job.seed,
        queryUsed: job.query,
        patternType: job.type,
        depth: job.depth || 1,
        country: job.options.country || 'us',
        language: job.options.language || 'en',
        suggestions: items,
        newCount: added,
        totalFound: activeTask.totalSuggestionsFound
      }).catch(() => {});

      // Deep Level 2 Wildcard expansion: For Level 1 suggestions, schedule * inner wildcards
      if (job.options.useDeepLevel2Wildcard && job.depth === 1) {
        for (const sugg of suggestions) {
          const lowerSugg = sugg.toLowerCase().trim();
          if (!enqueuedLevel2Set.has(lowerSugg) && lowerSugg !== job.seed.toLowerCase().trim()) {
            enqueuedLevel2Set.add(lowerSugg);
            const l2Variations = generateLevel2Wildcards(sugg);
            for (const l2 of l2Variations) {
              activeTask.queue.push({
                seed: job.seed,
                query: l2.query,
                type: l2.type,
                depth: 2,
                parentSuggestion: sugg,
                options: job.options
              });
              activeTask.totalQueries++;
            }
          }
        }
      }
    }

    activeTask.completedQueries++;
    broadcastStatus();

    // Rate pacing delay
    const delay = job.options.delayMs || 350;
    await new Promise(r => setTimeout(r, delay));
  }

  activeTask.isRunning = false;
  activeTask.currentVariation = '';
  activeTask.currentKeyword = '';
  broadcastStatus();

  // Notify finished
  chrome.runtime.sendMessage({
    type: 'KW_EXTRACTION_FINISHED',
    totalFound: activeTask.totalSuggestionsFound,
    completedQueries: activeTask.completedQueries
  }).catch(() => {});
}

/**
 * Tab Automation Fallback
 */
async function runTabAutomation(query) {
  try {
    const tab = await chrome.tabs.create({
      url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      active: false
    });

    await new Promise(r => setTimeout(r, 1200));

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const items = [];
        const selectorList = document.querySelectorAll('ul[role="listbox"] li, div[role="presentation"] ul li, .sbct, .wM6W7d span');
        selectorList.forEach(el => {
          const text = el.innerText?.trim();
          if (text && !items.includes(text)) {
            items.push(text);
          }
        });
        return items;
      }
    });

    if (tab.id) {
      await chrome.tabs.remove(tab.id).catch(() => {});
    }

    return results && results[0] && Array.isArray(results[0].result) ? results[0].result : [];
  } catch (err) {
    console.warn('[Instant KW] Tab automation error:', err);
    return [];
  }
}

/**
 * Broadcast active task status to UI
 */
function broadcastStatus() {
  chrome.runtime.sendMessage({
    type: 'KW_STATUS_UPDATE',
    status: {
      isRunning: activeTask.isRunning,
      currentKeyword: activeTask.currentKeyword,
      currentVariation: activeTask.currentVariation,
      totalQueries: activeTask.totalQueries,
      completedQueries: activeTask.completedQueries,
      totalSuggestionsFound: activeTask.totalSuggestionsFound,
      progressPercent: activeTask.totalQueries > 0 
        ? Math.round((activeTask.completedQueries / activeTask.totalQueries) * 100)
        : 0
    }
  }).catch(() => {});
}

/**
 * Generate CSV string from keywords list with Country & Language
 */
function generateCSVString(seedKeyword, suggestionsMap, projectMetadata = {}) {
  const rows = [
    ['Seed Keyword', 'Suggested Keyword', 'Wildcard / Query Pattern', 'Pattern Type', 'Search Depth', 'Parent Suggestion', 'Country (GL)', 'Language (HL)', 'Rank Position', 'Timestamp']
  ];

  const items = Object.values(suggestionsMap);
  items.sort((a, b) => {
    if ((a.depth || 1) !== (b.depth || 1)) {
      return (a.depth || 1) - (b.depth || 1);
    }
    return a.keyword.localeCompare(b.keyword);
  });

  const defaultCountry = (projectMetadata.country || 'us').toUpperCase();
  const defaultLang = (projectMetadata.language || 'en').toUpperCase();

  for (const item of items) {
    rows.push([
      `"${(item.seed || seedKeyword).replace(/"/g, '""')}"`,
      `"${item.keyword.replace(/"/g, '""')}"`,
      `"${(item.queryUsed || '').replace(/"/g, '""')}"`,
      `"${(item.patternType || '').replace(/"/g, '""')}"`,
      `"Level ${item.depth || 1}"`,
      `"${(item.parentSuggestion || '').replace(/"/g, '""')}"`,
      `"${(item.country || defaultCountry).toUpperCase()}"`,
      `"${(item.language || defaultLang).toUpperCase()}"`,
      item.rank || 1,
      `"${item.timestamp || ''}"`
    ]);
  }

  return rows.map(r => r.join(',')).join('\r\n');
}

/**
 * Message listener for Extension Events
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'START_EXTRACTION') {
    const { keywords, options } = message;
    if (!keywords || !Array.isArray(keywords) || keywords.length === 0) {
      sendResponse({ success: false, error: 'No keywords provided' });
      return true;
    }

    const mergedOptions = { ...defaultSettings, ...options };
    const queue = [];

    keywords.forEach(seed => {
      const variations = generateVariations(seed, mergedOptions);
      variations.forEach(v => {
        queue.push({
          seed: seed.trim(),
          query: v.query,
          type: v.type,
          options: mergedOptions
        });
      });
    });

    activeTask = {
      isRunning: true,
      isPaused: false,
      totalQueries: queue.length,
      completedQueries: 0,
      totalSuggestionsFound: 0,
      currentKeyword: keywords[0].trim(),
      currentVariation: '',
      queue: queue,
      resultsByKeyword: {},
      startedAt: Date.now(),
      stopRequested: false
    };

    sendResponse({ success: true, totalQueries: queue.length });
    processQueue();
    return true;
  }

  if (message.type === 'STOP_EXTRACTION') {
    activeTask.stopRequested = true;
    activeTask.isRunning = false;
    broadcastStatus();
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'GET_STATUS') {
    sendResponse({
      isRunning: activeTask.isRunning,
      currentKeyword: activeTask.currentKeyword,
      currentVariation: activeTask.currentVariation,
      totalQueries: activeTask.totalQueries,
      completedQueries: activeTask.completedQueries,
      totalSuggestionsFound: activeTask.totalSuggestionsFound,
      progressPercent: activeTask.totalQueries > 0 
        ? Math.round((activeTask.completedQueries / activeTask.totalQueries) * 100)
        : 0
    });
    return true;
  }

  if (message.type === 'GET_ALL_DATA') {
    chrome.storage.local.get(STORAGE_KEY_DATA, (stored) => {
      sendResponse({ success: true, data: stored[STORAGE_KEY_DATA] || {} });
    });
    return true;
  }

  if (message.type === 'DELETE_KEYWORD') {
    const { seed } = message;
    chrome.storage.local.get(STORAGE_KEY_DATA, async (stored) => {
      const data = stored[STORAGE_KEY_DATA] || {};
      if (data[seed]) {
        delete data[seed];
        await chrome.storage.local.set({ [STORAGE_KEY_DATA]: data });
      }
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'CLEAR_ALL_DATA') {
    chrome.storage.local.remove(STORAGE_KEY_DATA, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'EXPORT_KEYWORD_CSV') {
    const { seed } = message;
    chrome.storage.local.get(STORAGE_KEY_DATA, async (stored) => {
      const data = stored[STORAGE_KEY_DATA] || {};
      const project = data[seed];

      if (!project || !project.suggestions || Object.keys(project.suggestions).length === 0) {
        sendResponse({ success: false, error: 'No suggestions found for keyword' });
        return;
      }

      const country = (project.country || 'us').toLowerCase();
      const language = (project.language || 'en').toLowerCase();
      const csvContent = generateCSVString(seed, project.suggestions, project);
      const sanitizedName = seed.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
      const filename = `instant_kw_${sanitizedName}_${country}_${language}_suggestions.csv`;
      const dataUrl = `data:text/csv;charset=utf-8,${encodeURIComponent(csvContent)}`;

      try {
        await chrome.downloads.download({
          url: dataUrl,
          filename: filename,
          saveAs: false
        });
        sendResponse({ success: true, filename, country, language });
      } catch (e) {
        sendResponse({ success: true, csvContent, filename, country, language });
      }
    });
    return true;
  }

  if (message.type === 'EXPORT_ALL_CSVS') {
    chrome.storage.local.get(STORAGE_KEY_DATA, async (stored) => {
      const data = stored[STORAGE_KEY_DATA] || {};
      const keys = Object.keys(data);

      if (keys.length === 0) {
        sendResponse({ success: false, error: 'No keywords to export' });
        return;
      }

      for (const seed of keys) {
        const project = data[seed];
        if (project && project.suggestions && Object.keys(project.suggestions).length > 0) {
          const country = (project.country || 'us').toLowerCase();
          const language = (project.language || 'en').toLowerCase();
          const csvContent = generateCSVString(seed, project.suggestions, project);
          const sanitizedName = seed.replace(/[^a-zA-Z0-9_-]/g, '_').toLowerCase();
          const filename = `instant_kw_${sanitizedName}_${country}_${language}_suggestions.csv`;
          const dataUrl = `data:text/csv;charset=utf-8,${encodeURIComponent(csvContent)}`;

          try {
            await chrome.downloads.download({
              url: dataUrl,
              filename: filename,
              saveAs: false
            });
            await new Promise(r => setTimeout(r, 400));
          } catch (e) {
            console.warn('[Instant KW] Download error for', seed, e);
          }
        }
      }

      sendResponse({ success: true, exportedCount: keys.length });
    });
    return true;
  }
});
