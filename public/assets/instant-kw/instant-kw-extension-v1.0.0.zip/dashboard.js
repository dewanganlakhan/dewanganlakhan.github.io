/**
 * Instant KW - Dashboard Workspace Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const dashKeywordsInput = document.getElementById('dashKeywordsInput');
  const dashSelectCountry = document.getElementById('dashSelectCountry');
  const dashSelectLanguage = document.getElementById('dashSelectLanguage');
  const dashOptDeepL2 = document.getElementById('dashOptDeepL2');
  const btnDashStartHarvest = document.getElementById('btnDashStartHarvest');
  const projectsList = document.getElementById('projectsList');
  const totalProjectsBadge = document.getElementById('totalProjectsBadge');
  const btnDashExportAll = document.getElementById('btnDashExportAll');
  const btnDashClearAll = document.getElementById('btnDashClearAll');

  // Metrics
  const metricTotalSuggestions = document.getElementById('metricTotalSuggestions');
  const metricActiveProjectKw = document.getElementById('metricActiveProjectKw');
  const metricLastUpdated = document.getElementById('metricLastUpdated');

  // Toolbar & Table
  const activeSeedTitle = document.getElementById('activeSeedTitle');
  const activeSeedGeoBadge = document.getElementById('activeSeedGeoBadge');
  const activeSeedCountBadge = document.getElementById('activeSeedCountBadge');
  const tableFilterInput = document.getElementById('tableFilterInput');
  const btnCopyActiveList = document.getElementById('btnCopyActiveList');
  const patternFiltersBar = document.getElementById('patternFiltersBar');
  const suggestionsTableBody = document.getElementById('suggestionsTableBody');
  const dashToast = document.getElementById('dashToast');

  let state = {
    allData: {},
    activeSeed: null,
    activeFilterCategory: 'all',
    searchFilterText: ''
  };

  // 1. Load Data from Storage
  async function loadData(preferredSeed = null) {
    const stored = await chrome.storage.local.get('instant_kw_data');
    state.allData = stored.instant_kw_data || {};

    const seeds = Object.keys(state.allData);
    totalProjectsBadge.textContent = seeds.length;

    // Pick active seed
    if (preferredSeed && state.allData[preferredSeed]) {
      state.activeSeed = preferredSeed;
    } else if (!state.activeSeed || !state.allData[state.activeSeed]) {
      state.activeSeed = seeds.length > 0 ? seeds[0] : null;
    }

    renderSidebarProjects();
    updateMetrics();
    renderActiveTable();
  }

  // 2. Render Sidebar Project Items
  function renderSidebarProjects() {
    projectsList.innerHTML = '';
    const seeds = Object.keys(state.allData);

    if (seeds.length === 0) {
      projectsList.innerHTML = `<div class="empty-state-sidebar">No keyword projects yet.<br>Start a new harvest above!</div>`;
      return;
    }

    seeds.sort((a, b) => {
      const timeA = new Date(state.allData[a].updatedAt || 0).getTime();
      const timeB = new Date(state.allData[b].updatedAt || 0).getTime();
      return timeB - timeA;
    });

    seeds.forEach(seed => {
      const project = state.allData[seed];
      const count = project.totalSuggestions || (project.suggestions ? Object.keys(project.suggestions).length : 0);
      const isActive = seed === state.activeSeed;
      const countryCode = (project.country || 'us').toUpperCase();
      const langCode = (project.language || 'en').toUpperCase();

      const item = document.createElement('div');
      item.className = `project-item ${isActive ? 'active' : ''}`;
      item.innerHTML = `
        <div class="project-info">
          <span class="project-name" title="${seed}">
            ${escapeHtml(seed)}
            <span class="project-geo-badge">${countryCode}/${langCode}</span>
          </span>
          <span class="project-meta">${count} suggestions</span>
        </div>
        <div class="project-actions">
          <button class="mini-icon-btn export-btn" title="Export CSV for ${escapeHtml(seed)} (${countryCode}_${langCode})">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="7 10 12 15 17 10"></polyline>
              <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
          </button>
          <button class="mini-icon-btn delete delete-btn" title="Delete project">
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
          </button>
        </div>
      `;

      // Select Project
      item.addEventListener('click', (e) => {
        if (e.target.closest('.mini-icon-btn')) return;
        state.activeSeed = seed;
        renderSidebarProjects();
        updateMetrics();
        renderActiveTable();
      });

      // Export Single Keyword CSV
      item.querySelector('.export-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        exportSingleKeyword(seed);
      });

      // Delete Project
      item.querySelector('.delete-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirm(`Delete project "${seed}" and all its saved keywords?`)) {
          chrome.runtime.sendMessage({ type: 'DELETE_KEYWORD', seed }, () => {
            if (state.activeSeed === seed) state.activeSeed = null;
            loadData();
            showToast(`Deleted "${seed}"`);
          });
        }
      });

      projectsList.appendChild(item);
    });
  }

  // 3. Update Metrics Header
  function updateMetrics() {
    let grandTotal = 0;
    Object.values(state.allData).forEach(proj => {
      grandTotal += proj.totalSuggestions || 0;
    });

    metricTotalSuggestions.textContent = grandTotal.toLocaleString();
    metricActiveProjectKw.textContent = state.activeSeed || 'None';

    if (state.activeSeed && state.allData[state.activeSeed]) {
      const updated = new Date(state.allData[state.activeSeed].updatedAt);
      metricLastUpdated.textContent = updated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      metricLastUpdated.textContent = '-';
    }
  }

  // 4. Render Table
  function renderActiveTable() {
    if (!state.activeSeed || !state.allData[state.activeSeed]) {
      activeSeedTitle.textContent = 'Select a Keyword Project';
      if (activeSeedGeoBadge) activeSeedGeoBadge.textContent = 'US • EN';
      activeSeedCountBadge.textContent = '0 keywords';
      suggestionsTableBody.innerHTML = `<tr><td colspan="8" class="table-empty">No keywords loaded. Start by harvesting keywords or selecting a saved project.</td></tr>`;
      return;
    }

    const project = state.allData[state.activeSeed];
    const countryCode = (project.country || 'us').toUpperCase();
    const langCode = (project.language || 'en').toUpperCase();

    activeSeedTitle.textContent = project.seed;
    if (activeSeedGeoBadge) {
      activeSeedGeoBadge.textContent = `${countryCode} • ${langCode}`;
    }

    const allSuggestions = Object.values(project.suggestions || {});
    activeSeedCountBadge.textContent = `${allSuggestions.length} keywords`;

    // Apply Filter
    let filtered = allSuggestions.filter(item => {
      // Category filter
      const type = (item.patternType || '').toLowerCase();
      const isDeepL2 = (item.depth === 2) || type.includes('deep');

      if (state.activeFilterCategory === 'exact' && !type.includes('exact') && !type.includes('wildcard') && !type.includes('underscore')) {
        return false;
      }
      if (state.activeFilterCategory === 'deep' && !isDeepL2) {
        return false;
      }
      if (state.activeFilterCategory === 'alpha' && !type.includes('alphabet')) {
        return false;
      }
      if (state.activeFilterCategory === 'question' && !type.includes('question')) {
        return false;
      }
      if (state.activeFilterCategory === 'modifier' && !type.includes('modifier')) {
        return false;
      }
      if (state.activeFilterCategory === 'number' && !type.includes('number')) {
        return false;
      }

      // Search text filter
      if (state.searchFilterText) {
        const q = state.searchFilterText.toLowerCase();
        const matchKw = item.keyword.toLowerCase().includes(q);
        const matchQuery = (item.queryUsed || '').toLowerCase().includes(q);
        const matchParent = (item.parentSuggestion || '').toLowerCase().includes(q);
        const matchType = type.includes(q);
        return matchKw || matchQuery || matchParent || matchType;
      }

      return true;
    });

    // Sort by depth first then keyword alphabetical
    filtered.sort((a, b) => {
      if ((a.depth || 1) !== (b.depth || 1)) return (a.depth || 1) - (b.depth || 1);
      return a.keyword.localeCompare(b.keyword);
    });

    if (filtered.length === 0) {
      suggestionsTableBody.innerHTML = `<tr><td colspan="8" class="table-empty">No suggestions match the active filters.</td></tr>`;
      return;
    }

    suggestionsTableBody.innerHTML = '';
    filtered.forEach((item, index) => {
      const tr = document.createElement('tr');

      let categoryClass = 'category-tag';
      const pType = item.patternType || 'Suggestion';
      const isL2 = (item.depth === 2);

      if (isL2 || pType.toLowerCase().includes('deep')) categoryClass += ' deep';
      else if (pType.toLowerCase().includes('question')) categoryClass += ' question';
      else if (pType.toLowerCase().includes('wildcard') || pType.toLowerCase().includes('exact')) categoryClass += ' wildcard';
      else if (pType.toLowerCase().includes('modifier')) categoryClass += ' modifier';

      const depthBadge = isL2 
        ? `<span class="depth-badge l2" title="Generated from inner wildcard search on '${escapeHtml(item.parentSuggestion || '')}'">⚡ Level 2</span>`
        : `<span class="depth-badge">Level 1</span>`;

      const itemCountry = (item.country || countryCode).toUpperCase();
      const itemLang = (item.language || langCode).toUpperCase();

      tr.innerHTML = `
        <td class="rank-badge">${index + 1}</td>
        <td><span class="kw-pill">${escapeHtml(item.keyword)}</span></td>
        <td><span class="pattern-badge">${escapeHtml(item.queryUsed || '-')}</span></td>
        <td><span class="${categoryClass}">${escapeHtml(pType)}</span></td>
        <td>${depthBadge}</td>
        <td><span class="table-geo-badge">${itemCountry}/${itemLang}</span></td>
        <td class="rank-badge">#${item.rank || 1}</td>
        <td>
          <button class="table-action-btn copy-row-btn" data-kw="${escapeHtml(item.keyword)}">Copy</button>
        </td>
      `;

      tr.querySelector('.copy-row-btn').addEventListener('click', () => {
        navigator.clipboard.writeText(item.keyword).then(() => {
          showToast(`Copied "${item.keyword}"`);
        });
      });

      suggestionsTableBody.appendChild(tr);
    });
  }

  // 5. Filter Category Pills
  patternFiltersBar.querySelectorAll('.filter-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      patternFiltersBar.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      state.activeFilterCategory = btn.getAttribute('data-filter');
      renderActiveTable();
    });
  });

  // Table search text filter
  tableFilterInput.addEventListener('input', () => {
    state.searchFilterText = tableFilterInput.value.trim();
    renderActiveTable();
  });

  // 6. Harvest Trigger from Dashboard
  btnDashStartHarvest.addEventListener('click', () => {
    const raw = dashKeywordsInput.value.trim();
    if (!raw) {
      showToast('Please enter seed keyword(s) to harvest.');
      dashKeywordsInput.focus();
      return;
    }

    const keywords = raw.split(/[\n,]+/).map(k => k.trim()).filter(k => k.length > 0);
    if (keywords.length === 0) return;

    btnDashStartHarvest.disabled = true;
    btnDashStartHarvest.textContent = 'Harvesting...';

    chrome.runtime.sendMessage({
      type: 'START_EXTRACTION',
      keywords: keywords,
      options: {
        country: dashSelectCountry ? dashSelectCountry.value : 'us',
        language: dashSelectLanguage ? dashSelectLanguage.value : 'en',
        useDeepLevel2Wildcard: dashOptDeepL2 ? dashOptDeepL2.checked : true
      }
    }, (res) => {
      dashKeywordsInput.value = '';
      showToast(`Started harvesting for ${keywords.length} keyword(s) [${dashSelectCountry.value.toUpperCase()}/${dashSelectLanguage.value.toUpperCase()}]!`);
    });
  });

  // 7. Single Keyword CSV Export (1 File for active keyword)
  function exportSingleKeyword(seed) {
    if (!seed) return;
    chrome.runtime.sendMessage({ type: 'EXPORT_KEYWORD_CSV', seed }, (res) => {
      if (res && res.success) {
        if (res.csvContent) {
          triggerBrowserDownload(res.csvContent, res.filename);
        }
        showToast(`Exported ${res.filename || `CSV for "${seed}"`}!`);
      } else {
        showToast(res?.error || 'No suggestions to export.');
      }
    });
  }

  // 8. Export All Projects (1 CSV per Keyword)
  btnDashExportAll.addEventListener('click', () => {
    showToast('Exporting 1 CSV for each keyword project...');
    chrome.runtime.sendMessage({ type: 'EXPORT_ALL_CSVS' }, (res) => {
      if (res && res.success) {
        showToast(`Generated ${res.exportedCount} CSV file(s)!`);
      } else {
        showToast(res?.error || 'No keywords to export.');
      }
    });
  });

  // 9. Copy Active / Filtered List
  btnCopyActiveList.addEventListener('click', () => {
    if (!state.activeSeed || !state.allData[state.activeSeed]) {
      showToast('No keyword project selected.');
      return;
    }

    const items = Object.values(state.allData[state.activeSeed].suggestions || {});
    if (items.length === 0) {
      showToast('No keywords to copy.');
      return;
    }

    const kwList = items.map(i => i.keyword);
    navigator.clipboard.writeText(kwList.join('\n')).then(() => {
      showToast(`Copied ${kwList.length} keywords to clipboard!`);
    });
  });

  // 10. Clear All Data
  btnDashClearAll.addEventListener('click', () => {
    if (confirm('Are you sure you want to delete all saved keyword projects? This cannot be undone.')) {
      chrome.runtime.sendMessage({ type: 'CLEAR_ALL_DATA' }, () => {
        state.allData = {};
        state.activeSeed = null;
        loadData();
        showToast('All keyword projects cleared.');
      });
    }
  });

  // Real-time listener
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'KW_NEW_SUGGESTIONS' || msg.type === 'KW_EXTRACTION_FINISHED') {
      btnDashStartHarvest.disabled = false;
      btnDashStartHarvest.textContent = 'Harvest Suggestions';
      loadData(msg.seed || state.activeSeed);
    }
  });

  // Helpers
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function triggerBrowserDownload(csvContent, filename) {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function showToast(msg) {
    dashToast.textContent = msg;
    dashToast.classList.remove('hidden');
    dashToast.style.opacity = '1';
    setTimeout(() => {
      dashToast.style.opacity = '0';
      setTimeout(() => dashToast.classList.add('hidden'), 300);
    }, 2800);
  }

  // Initial Load
  await loadData();
});
